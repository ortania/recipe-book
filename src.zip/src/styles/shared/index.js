/**
 * src/styles/shared/index.js
 *
 * Re-exports all shared CSS modules for convenient importing:
 *
 * Usage:
 *   import { btnClasses, layoutClasses, inputClasses } from '@/styles/shared';
 *
 * Or import a single module directly:
 *   import btnClasses from '@/styles/shared/buttons.module.css';
 */

export { default as btnClasses } from './buttons.module.css';
export { default as layoutClasses } from './layout.module.css';
export { default as inputClasses } from './inputs.module.css';
export { default as formSharedClasses } from './form-shared.module.css';
export { default as categoryChipsClasses } from './category-chips.module.css';
export { default as categoryTagsClasses } from './category-tags.module.css';
export { default as onboardingSharedClasses } from './onboarding-shared.module.css';
export { default as recipeCheckboxClasses } from './recipe-checkbox.module.css';
