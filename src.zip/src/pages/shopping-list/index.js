export { default } from "./ShoppingList";
