export { default } from "./GlobalRecipes";
